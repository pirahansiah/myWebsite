# Local overrides - CLAUDE.local.md (never committed)

- Plan-first for architecture changes; explain risky steps before running them.
- Always print the exact test/build command that was executed.
- Python work: `conda activate py314` only (`py312` only for zero-point calibration).
  Do not create `.venv`, `venv`, `virtualenv` or uv-managed environments here.
- Model pins for this machine live in `settings.json`; do not edit them outside `~/.claude/settings.json`
  or a project override unless asked.

## Memory mirroring (keep both directions in sync, same session)

- Claude config: `~/Documents/.claude` (this folder; `~/.claude` is not present on this Mac)
- Copilot memory: `~/Library/Application Support/Code/User/globalStorage/github.copilot-chat/memory-tool/memories/`

If either side changes, update the other before the session ends.

## Completion discipline

Before finishing any task, answer both and append to `README.md`:
- what are you least confident about it right now?
- what is the biggest things that I do not realised it now?

Completion trigger words: `job done`, `good`, `finished`, `sucessful`, `complite`, `test ok`.

## Machine notes

- macOS 27.0.1 arm64, conda `py314`, RISC-V + edge accelerator toolchains under `~/Documents`.
- Claude Code CLI on this Mac is old relative to the docs; run `claude update` before relying on
  mods, `$.ui.selection()`, `/code-review --max-findings`, or `xhigh` effort.
